import * as apiConfig from "../configs/apiConfig";
import { getAuthManager } from "auth";

const API_BASE_URL = apiConfig.API_BASE_URL;

const checkStatusNoContent = (status) => [204, 304].includes(status);

const buildUrl = (endpoint, query) => {
  const url = new URL(`${API_BASE_URL}/${endpoint}`);
  Object.entries(query).forEach(([key, value]) => {
    url.searchParams.append(key, value);
  });
  return url;
};

export const callApi = async (endpoint, options = {}) => {
  const tokenManager = getAuthManager().getTokenManager();
  const token = await tokenManager.getAccessToken();
  const headers = {
    Authorization: `Bearer ${token}`,
    ...options?.header,
    "Content-Type": "application/json",
  };

  const throwEx = options.throwEx ?? false;
  delete options.throwEx;

  const query = options.query || {};
  delete options.query;

  try {
    let dataJson = {};
    const resp = await fetch(buildUrl(endpoint, query), {
      ...options,
      headers
    });

    const contentType = resp.headers.get("Content-Type");
    //const contentLength = resp.headers.get('Content-Length');
    if (
      !checkStatusNoContent(resp.status) &&
      contentType &&
      contentType.includes("application/json")
    ) {
      dataJson = await resp.json();
    }

    if (!resp.ok) {
      if (throwEx || Object.keys(dataJson).length == 0) {
        const error = new Error(`HTTP error! status: ${resp.status}`);
        error.details = dataJson;
        throw error;
      }
    }

    return dataJson;
  } catch (error) {
    console.error("API Fetch Error:", error);
    if (!throwEx) {
      return {
        code: error.code || 500,
        error: error.message || "An error occurred while fetching data.",
        status: "error",
      };
    }
    throw error;
  }
};
