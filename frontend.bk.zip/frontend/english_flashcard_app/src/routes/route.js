import { createBrowserRouter } from "react-router-dom";
import * as topicsLoader from "./loaders/topicLoader";
import * as vocabsLoader from "./loaders/vocabLoader";
import * as topicsAction from "./actions/topicAction";
import * as vocabsAction from "./actions/vocabAction";
import * as transAction from "./actions/transAction";
import * as loginAction from "./actions/loginAction";
import * as registerAction from "./actions/registerAction";
import * as profileLoader from "./loaders/profileLoader";
import * as dashboardLoader from "./loaders/dashboardLoader";
import * as profileAction from "./actions/profileAction";
import Error from "../components/errors/Error";
import Login from "../pages/Login";
import Register from "../pages/Register";
import Layout from "../pages/Layout";
import PrivatePage from "../components/PrivatePage";
import Test from "../pages/Test";

const isShouldNotRevalidate = (formData, actionResult) => {
  return formData?.has("_not_revalidate") || actionResult?.status === "error";
};

const defaultShouldRevalidate = ({ formData, actionResult }) => {
  return !isShouldNotRevalidate(formData, actionResult);
};

const topicsShouldRevalidate = ({
  formData,
  actionResult,
  currentUrl,
  nextUrl,
}) => {
  if (formData) {
    if (isShouldNotRevalidate(formData, actionResult)) {
      return false;
    }
  }
  if (currentUrl.pathname !== nextUrl.pathname) {
    const includeExceptionPaths = [
      "/topics",
      "/topics/new",
    ].includes(
      currentUrl.pathname, 
      nextUrl.pathname
    );
    if (includeExceptionPaths) {
      return false;
    }
  }
  return true;
};

const topicShouldRevalidate = ({
  formData,
  actionResult,
  currentUrl,
  nextUrl,
}) => {
  if (formData) {
    if (isShouldNotRevalidate(formData, actionResult)) {
      return false;
    }
    const formName = formData?.get("_form_name") ?? "";
    if (formName.includes("vocab")) {
      return true;
    }
  }
  return false;
};

export const createAppRouter = () => createBrowserRouter(
  [
    {
      path: "/logout",
      action: loginAction.logout,
    },
    {
      element: <Layout isGuest={true} />,
      children: [
        {
          path: "/test",
          element: <Test />,
        },
        {
          path: "/login",
          element: <Login />,
          action: loginAction.login,
        },
        {
          path: "/register",
          element: <Register />,
          action: registerAction.register,
        },
      ],
    },
    {
      path: "/",
      element: <Layout />,
      children: [
        {
          errorElement: <Error />,
          children: [
            {
              index: true,
              path: "/",
              element: <PrivatePage pageName="Dashboard" />,
              loader: dashboardLoader.getDashboardSummaryLoader,
            },
            {
              path: "/dashboard",
              element: <PrivatePage pageName="Dashboard" />,
              loader: dashboardLoader.getDashboardSummaryLoader,
            },
            {
              path: "/settings",
              element: <PrivatePage pageName="Settings" />,
            },
            {
              path: "/profile",
              element: <PrivatePage pageName="Profile" />,
              loader: profileLoader.getProfile,
              action: profileAction.updateProfile,
              shouldRevalidate: defaultShouldRevalidate,
            },
            {
              path: "/topics",
              element: <PrivatePage pageName="Topics" />,
              loader: topicsLoader.getTopics,
              shouldRevalidate: topicsShouldRevalidate,
              children: [
                {
                  path: "new",
                  element: <PrivatePage pageName="TopicModal" />,
                  action: topicsAction.createTopic,
                },
                {
                  path: "delete",
                  action: topicsAction.deleteTopics,
                },
              ],
            },
            {
              path: "/topic/:topicId/:action?",
              element: <PrivatePage pageName="Topic" />,
              loader: topicsLoader.getTopic,
              action: topicsAction.editTopic,
              shouldRevalidate: topicShouldRevalidate,
              children: [
                {
                  path: "members/update",
                  action: topicsAction.updateMembers,
                },
                {
                  path: "vocab/import",
                  action: vocabsAction.importVocabs,
                },
                {
                  path: "vocab/delete",
                  action: vocabsAction.deleteVocabs,
                },
                {
                  path: "vocab/:vocabId/:action?",
                  element: <PrivatePage pageName="VocabModal" />,
                  loader: vocabsLoader.getVocab,
                  action: vocabsAction.editVocab,
                  shouldRevalidate: defaultShouldRevalidate,
                },
                {
                  path: "vocab/translation_tab/create",
                  action: vocabsAction.createTranslationTab,
                  shouldRevalidate: () => false,
                },
              ],
            },
            {
              path: "/translation/:transId",
              action: transAction.editTrans,
              shouldRevalidate: defaultShouldRevalidate,
            },
            {
              path: "/topic/:topicId/learn",
              element: <PrivatePage pageName="TopicLearn" />,
              loader: topicsLoader.getTopic,
            },
          ],
        },
      ],
    },
  ],
  {
    future: {
      v7_skipActionErrorRevalidation: true,
    },
  },
);
