import * as topicApi from "../../services/topicApi";
import { 
  createThunkWithCallback, 
  dispatchSuccessAlert, 
  rejectWithErrorValue 
} from "./commonAction";

export const getTopicsThunk = createThunkWithCallback(
  "topics/get",
  async ({ filters }, { dispatch, rejectWithValue }) => {
    const response = await topicApi.getTopics(filters);
    if (response.status === "error") {
      return rejectWithErrorValue(dispatch, rejectWithValue, response);
    }
    return response;
  },
);

export const getTopicThunk = createThunkWithCallback(
  "topic/get",
  async ({ topicId }, { dispatch, rejectWithValue }) => {
    const response = await topicApi.getTopicById(topicId);
    if (response.status === "error") {
      return rejectWithErrorValue(dispatch, rejectWithValue, response);
    }
    return response;
  },
);

export const createTopicThunk = createThunkWithCallback(
  "topic/create",
  async ({ data }, { dispatch, rejectWithValue }) => {
    const response = await topicApi.createTopic(data);
    if (response.status === "error") {
      return rejectWithErrorValue(dispatch, rejectWithValue, response);
    }
    dispatchSuccessAlert(dispatch, "Topic is created successfully");
    return response;
  },
);

export const updateTopicThunk = createThunkWithCallback(
  "topic/update",
  async ({ topicId, data }, { dispatch, rejectWithValue }) => {
    const response = await topicApi.updateTopic(topicId, data);
    if (response.status === "error") {
      return rejectWithErrorValue(dispatch, rejectWithValue, response);
    }
    dispatchSuccessAlert(dispatch, "Topic is updated successfully");
    return response;
  },
);

export const deleteTopicThunk = createThunkWithCallback(
  "topic/delete",
  async ({ topicId }, { dispatch, rejectWithValue }) => {
    const params = { id: topicId };
    const response = await topicApi.deleteTopic(topicId);
    if (response?.status === "error") {
      return rejectWithErrorValue(dispatch, rejectWithValue, response);
    }

    dispatchSuccessAlert(dispatch, "Topic is deleted successfully");
    return {
      status: "success",
      data: params,
    };
  },
);

export const deleteTopicsThunk = createThunkWithCallback(
  "topics/delete",
  async (_, { dispatch }) => {
    await topicApi.deleteTopics();
    dispatchSuccessAlert(dispatch, "Topics are deleted successfully");
    return {
      status: "success",
    };
  },
);

export const updateTopicMembersThunk = createThunkWithCallback(
  "topic/members/update",
  async ({ topicId, data }, { dispatch, rejectWithValue }) => {
    const response = await topicApi.updateTopicMembers(topicId, data);
    if (response.status === "error") {
      return rejectWithErrorValue(dispatch, rejectWithValue, response);
    }
    dispatchSuccessAlert(dispatch, "Topic members are updated successfully");
    return response;
  },
);

export const memberInteractTopicThunk = createThunkWithCallback(
  "topic/member/interact",
  async ({ topicId, action }, { dispatch, rejectWithValue }) => {
    const params = { id: topicId };
    try {
      let response, message;
      switch (action) {
        case "subcribe":
          response = await topicApi.subcribeTopic(topicId);
          message = "Subcribed topic successfully";
          break;
        case "unsubcribe":
          response = await topicApi.unsubcribeTopic(topicId);
          message = "Unsubcribed topic successfully";
          break;
        default:
          throw new Error("Invalid action for interactTopicThunk");
      }

      if (response?.status === "success") {
        dispatchSuccessAlert(dispatch, message);
        return response
      }
      return rejectWithErrorValue(dispatch, rejectWithValue, response);
    } catch (error) {
      return rejectWithErrorValue(dispatch, rejectWithValue, error);
    }
  },
);
