export const setLangReducer = (state, action) => action.payload;
