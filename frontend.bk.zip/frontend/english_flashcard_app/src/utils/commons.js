export const getRandomInt = (min, max) => {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1) + min);
};

export const getRandomIntWithExceptions = (min, max, exceptions) => {
  min = Math.ceil(min);
  max = Math.floor(max);
  let possibleNumbers = [];

  for (let i = min; i <= max; i++) {
    if (!exceptions.includes(i)) {
      possibleNumbers.push(i);
    }
  }

  if (possibleNumbers.length === 0) {
    throw new Error("No valid numbers available in the range.");
  }

  const randomIndex = Math.floor(Math.random() * possibleNumbers.length);
  return possibleNumbers[randomIndex];
};
export const getNextMaxId = (items, field) => {
  if (!items || items.length === 0) {
    return 1; // Return 1 if the array is empty or undefined
  }
  return Math.max(...items.map(v => v[field])) + 1;
}

export const parseJsonObjectValues = (rawValue) => {
  if (typeof rawValue !== "string" || rawValue.trim() === "") return null;

  try {
    const parsed = JSON.parse(rawValue);
    if (!parsed || typeof parsed !== "object") return null;

    return Object.values(parsed);
  } catch {
    return null;
  }
};

export const generateUniqueId = () => {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  return `${Date.now()}-${Math.random().toString(36).slice(2)}`;
};
