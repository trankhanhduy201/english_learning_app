import {
  memo,
  useCallback,
  useEffect,
  useState,
  useTransition,
  useRef,
  useMemo,
} from "react";
import { Link, useFetcher } from "react-router-dom";
import ImportTextModal from "../topic/ImportTextModal";
import ListVocabTable from "./ListVocabTable";
import { debounce } from "lodash";
import LoadingOverlay from "../../LoadingOverlay";
import DeleteConfirmButton from "../../DeleteConfirmButton";
import useAudio from "../../../hooks/useAudio";
import { useTopicContext } from "../../../contexts/TopicContext";
import useFetchAudioNotification from "../../../hooks/useFetchAudioNotification";

const ListVocabDetail = memo(({ vocabDatas, topicId, onDeleteVocabSuccess }) => {
  const curSearchText = useRef("");
  const [ vocabs, setVocabs ] = useState([]);
  const [ showImportTextModal, setShowImportTextModal ] = useState(false);
  const [ isSearching, transition ] = useTransition();
  const { audioRef, onPlayAudio } = useAudio();
  const delVocabFetcher = useFetcher();
  const { topic } = useTopicContext();

  const filterVocabs = useCallback((searchText) => {
    const normalized = (searchText ?? "").toString().trim().toLowerCase();
    setVocabs(() => {
      if (!normalized) {
        return [...vocabDatas];
      }
      return vocabDatas.filter((vocab) =>
        vocab.word.toLowerCase().includes(normalized),
      );
    });
  }, [vocabDatas]);

  useEffect(() => {
    filterVocabs(curSearchText.current);
  }, [vocabDatas]);

  const onCloseImportTextModal = useCallback(() => {
    setShowImportTextModal(false);
  });

  const onSearchVocab = useMemo(() => {
    const debounced = debounce((searchText) => {
      const normalized = (searchText ?? "").toString().trim().toLowerCase();
      curSearchText.current = normalized;
      transition(() => {
        filterVocabs(normalized);
      });
    }, 300);
    return debounced;
  }, [filterVocabs]);

  useEffect(() => {
    return () => {
      onSearchVocab.cancel();
    };
  }, [onSearchVocab]);

  return (
    <>
      <audio ref={audioRef} />
      <div className="position-relative">
        {delVocabFetcher.state === "submitting" && (
          <LoadingOverlay position="absolute" background="white" />
        )}
        <ListVocabTable
          vocabs={vocabs}
          topicId={topicId}
          isSearching={isSearching}
          onSearchVocab={onSearchVocab}
          onPlayAudio={onPlayAudio}
          delVocabFetcher={delVocabFetcher}
          onDeleteVocabSuccess={onDeleteVocabSuccess}
        />
        <div className="d-flex justify-content-end mt-2">
          <Link
            to={`/topic/${topicId}/vocab/export`}
            className="btn btn-secondary me-2"
          >
            <i className="bi bi-download"></i>
            <span className="btn-text --d-sm-none"> Export</span>
          </Link>
          <button
            onClick={() => setShowImportTextModal(true)}
            className="btn btn-secondary me-2"
          >
            <i className="bi bi-upload"></i>
            <span className="btn-text --d-sm-none"> Import</span>
          </button>
          <Link
            to={`/topic/${topicId}/vocab/new`}
            className="btn btn-secondary me-2"
          >
            <i className="bi bi-plus-circle"></i>
            <span className="btn-text --d-sm-none"> New</span>
          </Link>
          <DeleteConfirmButton
            label="Delete all"
            action={`/topic/${topicId}/vocab/delete`}
            formName={"deleting_all_vocab"}
            confirmMessage={`Are you sure you want to delete all vocabularies of "${topic?.name}" topic?`}
          />
        </div>
        {showImportTextModal && (
          <ImportTextModal
            topicId={topicId}
            learningLang={topic?.learning_language} // <-- use context value
            onClose={onCloseImportTextModal}
          />
        )}
      </div>
    </>
  );
});

const ListVocab = memo(({ vocabDatas, topicId }) => {
  const [vocabs, setVocabs] = useState([]);
  const { audioDatas } = useFetchAudioNotification();

  const handleDeleteVocabSuccess = useCallback((vocabId) => {
    setVocabs(prev => prev.filter(item => item.id != vocabId));
  }, []);

  useEffect(() => {
    setVocabs(vocabDatas);
  }, [vocabDatas])

  useEffect(() => {
    if (!audioDatas) return;
    setVocabs(prev => prev.map(item => {
      if (item.word in audioDatas) {
        return { ...item, audio: audioDatas[item.word] };
      }
      return item;
    }));
  }, [audioDatas])
  
  return (
    <ListVocabDetail
      vocabDatas={vocabs}
      topicId={topicId}
      onDeleteVocabSuccess={handleDeleteVocabSuccess}
    />
  )
});

export default ListVocab;
